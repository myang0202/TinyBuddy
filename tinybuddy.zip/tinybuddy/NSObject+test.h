//
//  NSObject+test.h
//  tinybuddy
//
//  Created by Matthew Yang on 10/8/16.
//  Copyright © 2016 Matthew Yang. All rights reserved.
//

#import <Foundation/Foundation.h>

@interface NSObject (test)

@end
