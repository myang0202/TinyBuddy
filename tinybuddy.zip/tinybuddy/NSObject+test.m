//
//  NSObject+test.m
//  tinybuddy
//
//  Created by Matthew Yang on 10/8/16.
//  Copyright © 2016 Matthew Yang. All rights reserved.
//

#import "NSObject+test.h"

@implementation NSObject (test)

@end
